# Mini Sistema de Gestión de Estudiantes

Proyecto de consola en TypeScript usando:
- Interfaces
- Clases
- Condicionales
- Bucles
- Funciones

## Ejecutar
npm install
npm start
