Ejercicio 1 de práctica en TypeScript
