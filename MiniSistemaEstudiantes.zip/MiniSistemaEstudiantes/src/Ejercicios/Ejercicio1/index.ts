console.log("Ejercicio 1 funcionando");
