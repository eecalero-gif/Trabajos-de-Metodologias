Ejercicio 2 de práctica en TypeScript
