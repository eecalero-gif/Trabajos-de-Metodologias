console.log("Ejercicio 2 funcionando");
