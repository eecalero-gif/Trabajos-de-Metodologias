console.log("Ejercicio 3 funcionando");
