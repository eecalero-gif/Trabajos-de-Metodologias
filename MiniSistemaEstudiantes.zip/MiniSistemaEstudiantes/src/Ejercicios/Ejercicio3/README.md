Ejercicio 3 de práctica en TypeScript
