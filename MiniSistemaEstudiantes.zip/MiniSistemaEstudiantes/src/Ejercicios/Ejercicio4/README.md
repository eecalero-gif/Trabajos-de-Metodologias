Ejercicio 4 de práctica en TypeScript
