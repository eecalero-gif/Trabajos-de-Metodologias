console.log("Ejercicio 4 funcionando");
